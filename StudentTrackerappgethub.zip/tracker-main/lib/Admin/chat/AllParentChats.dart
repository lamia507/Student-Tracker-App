import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tracker/Admin/chat/AdminChat.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/EditSellers.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/addSellers.dart';
import 'package:tracker/Parents/home/chat/chatPage.dart';
import 'package:tracker/Widgets/config/config.dart';

class AdminChats extends StatefulWidget {
  const AdminChats({super.key});

  @override
  State<AdminChats> createState() => _AdminChats();
}

class _AdminChats extends State<AdminChats> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('chats')
            .where("adminID", isEqualTo: currentUser)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final chats = snapshot.data!.docs;

          return ListView.builder(
            itemCount: chats.length,
            itemBuilder: (context, index) {
              var chat = chats[index];
              // Accessing data from the chat document
              String parentID = chat['parentID'];
              String parentName = chat['parentName'];
              String adminName = chat['adminName'];

              // Formatting the date
              DateTime date = (chat['date'] as Timestamp).toDate();
              String formattedDate = DateFormat.yMMMMd().add_jms().format(date);

              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(parentName[0]),
                  ),
                  title: Text(parentName),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Date: $formattedDate'),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.chat, color: TrackerApp.primaryColor),
                    onPressed: () {
                      Route route = MaterialPageRoute(
                          builder: (_) => AdminChat(
                                parentID: parentID,
                                parentName: parentName,
                                adminName: adminName,
                                chatID: chat.id,
                              ));
                      Navigator.push(context, route);
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  addingChatCollections(String id, adminName) async {
    String currentUser = FirebaseAuth.instance.currentUser?.uid ?? "";
    // check if it exisit
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("chats")
        .where("adminID", isEqualTo: id)
        .where("parentID", isEqualTo: currentUser)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatPage(
            adminID: querySnapshot.docs[0]['adminID'],
            adminName: querySnapshot.docs[0]['parentID'],
            chatID: querySnapshot.docs[0].id,
          ),
        ),
      );
    }
  }
}
