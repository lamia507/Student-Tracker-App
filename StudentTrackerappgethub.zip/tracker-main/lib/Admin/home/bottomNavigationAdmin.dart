import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/chat/AllParentChats.dart';
import 'package:tracker/Admin/home/AdminHomePage.dart';
import 'package:tracker/Admin/home/Services/AdminServices.dart';
import 'package:tracker/Admin/home/Profile/AdminProfilePage.dart';
import 'package:tracker/Common/ChoicePage.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Common/login.dart';

class bottomNavigationAdmin extends StatefulWidget {
  const bottomNavigationAdmin({super.key});

  @override
  State<bottomNavigationAdmin> createState() => _bottomNavigationAdmin();
}

class _bottomNavigationAdmin extends State<bottomNavigationAdmin> {
  int currentIndex = 0;
  final List<Widget> pages = [
    const AdminHomePage(),
    const AdminServices(),
    const AdminChats(),
    const AdminProfilePage(),
  ];

  final List<String> titles = [
    "Home",
    "Service",
    "Chat",
    "Profile Information",
  ];

  void _updatingIndex(int newSelectedIndex) {
    setState(() {
      currentIndex = newSelectedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          titles[currentIndex],
          style: const TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: TrackerApp.primaryColor,
        // actions: [
        //   IconButton(
        //     onPressed: () {
        //       FirebaseAuth.instance.signOut().then((value) {
        //         Route route = MaterialPageRoute(builder: (_) => ChoicePage());
        //         Navigator.push(context, route);
        //       });
        //     },
        //     icon: const Icon(Icons.logout),
        //     color: Colors.white,
        //   ),
        // ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home), // Valid icon
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.build), // Valid icon
            label: "Service",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat), // Valid icon
            label: "Chat",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle), // Valid icon
            label: "Profile",
          ),
        ],
        onTap: _updatingIndex,
        currentIndex: currentIndex,
        showUnselectedLabels: true,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black54,
        backgroundColor: TrackerApp.primaryColor,
        type: BottomNavigationBarType.fixed,
      ),
      body: pages.elementAt(currentIndex),
    );
  }
}
