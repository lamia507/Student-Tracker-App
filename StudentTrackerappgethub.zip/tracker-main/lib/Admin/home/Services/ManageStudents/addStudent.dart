import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'dart:ui' as ui;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class AddStudent extends StatefulWidget {
  const AddStudent({Key? key}) : super(key: key);

  @override
  State<AddStudent> createState() => _AddStudentState();
}

class _AddStudentState extends State<AddStudent> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _emergencyNumber1Controller =
      TextEditingController();
  final TextEditingController _emergencyNumber2Controller =
      TextEditingController();
  final TextEditingController _emergencyNumber3Controller =
      TextEditingController();
  final TextEditingController _healthConditionController =
      TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _qrData = ''; // Variable to store QR data
  late var ImageFIle;
  String? imageURL;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text("Add Student", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: () {
                generateQrCodeImage("dsafsd");
              },
              icon: Icon(Icons.dangerous))
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildTextField(_emailController, "Email", Icons.email),
                  _buildTextField(_nameController, "Name", Icons.person),
                  _buildTextField(_ageController, "Age", Icons.calendar_today),
                  _buildTextField(_addressController, "Address", Icons.home),
                  _buildTextField(_emergencyNumber1Controller,
                      "Emergency Number 1", Icons.phone),
                  _buildTextField(_emergencyNumber2Controller,
                      "Emergency Number 2", Icons.phone),
                  _buildTextField(_emergencyNumber3Controller,
                      "Emergency Number 3", Icons.phone),
                  _buildTextField(_healthConditionController,
                      "Health Condition", Icons.local_hospital),
                  SizedBox(height: 20),
                  _qrData.isNotEmpty
                      ? QrImageView(
                          data: _qrData,
                          version: QrVersions.auto,
                          size: 200.0,
                        )
                      : Container(), // Conditionally display QR code
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        ValidaitingDate();
                      }
                    },
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(TrackerApp.primaryColor),
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30))),
                    ),
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                      child: Text(
                        "Add Student",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return Container(
      margin: const EdgeInsets.all(5),
      child: TextFormField(
        controller: controller,
        cursorColor: Colors.black,
        decoration: InputDecoration(
          hintText: label,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: TrackerApp.primaryColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: TrackerApp.primaryColor),
            borderRadius: BorderRadius.circular(30),
          ),
          prefixIcon: Icon(icon, color: TrackerApp.primaryColor),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
      ),
    );
  }

  Future<File> generateQrCodeImage(String data) async {
    // Validate QR code data
    final qrValidationResult = QrValidator.validate(
      data: data,
      version: QrVersions.auto,
      errorCorrectionLevel: QrErrorCorrectLevel.L,
    );

    if (!qrValidationResult.isValid) {
      throw Exception('Invalid QR data');
    }

    // Generate QR code
    final qrCode = qrValidationResult.qrCode!;
    final painter = QrPainter.withQr(
      qr: qrCode,
      gapless: false,
    );

    // Render QR code to image
    final pictureRecorder = ui.PictureRecorder();
    final canvas = Canvas(pictureRecorder);
    final size = Size.square(200);
    painter.paint(canvas, size);
    final picture = pictureRecorder.endRecording();
    final image = await picture.toImage(200, 200);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    final pngBytes = byteData!.buffer.asUint8List();

    // Save image to file
    final tempDir = await getTemporaryDirectory();
    final file = File('${tempDir.path}/qr.png');
    await file.writeAsBytes(pngBytes);

    return file;
  }

  ValidaitingDate() async {
    showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return const LoadingAlertDialog(
          message: "Adding student, please wait...",
        );
      },
    );
    String documentId =
        FirebaseFirestore.instance.collection('students').doc().id;

    String currentUser = FirebaseAuth.instance.currentUser?.uid ?? "";
    // Gettign QR Code
    await gettingImageURL(documentId);

    print("Data data ${imageURL}");

    try {
      Map<String, dynamic> studentData = {
        'email': _emailController.text.trim(),
        'name': _nameController.text.trim(),
        'age': _ageController.text.trim(),
        'Money': "",
        'address': _addressController.text.trim(),
        'emergencyNumber1': _emergencyNumber1Controller.text.trim(),
        'emergencyNumber2': _emergencyNumber2Controller.text.trim(),
        'emergencyNumber3': _emergencyNumber3Controller.text.trim(),
        'healthCondition': _healthConditionController.text.trim(),
        'parentID': currentUser,
        'qrData': imageURL, // This will be generated later
        'createdOn': FieldValue.serverTimestamp(),
      };

      await FirebaseFirestore.instance
          .collection('students')
          .doc(documentId)
          .set(studentData)
          .then((_) {
        setState(() {
          _qrData =
              'ID: $documentId, Name: ${_nameController.text}'; // Generate QR data
        });
        SavingQR(documentId);
        Navigator.pop(context); // Close the loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Student added successfully')));
        _clearFormFields();
      }).catchError((error) {
        Navigator.pop(context); // Close the loading dialog
        showDialog(
          context: context,
          builder: (BuildContext context) =>
              ErrorAlertDialog(message: "Failed to add student: $error"),
        );
      });
    } catch (error) {
      Navigator.pop(context); // Close the loading dialog
      showDialog(
        context: context,
        builder: (BuildContext context) =>
            ErrorAlertDialog(message: "An error occurred: $error"),
      );
    }
  }

  Future<String> gettingImageURL(String documentId) async {
    final File qrImageFile = await generateQrCodeImage(documentId);

    if (qrImageFile.path.isNotEmpty) {
      String imageName =
          "QRS/${DateTime.now().microsecondsSinceEpoch.toString()}.png";
      FirebaseStorage storage = FirebaseStorage.instance;
      TaskSnapshot snapshot = await storage.ref(imageName).putFile(qrImageFile);
      final String downloadUrl = await snapshot.ref.getDownloadURL();
      imageURL = downloadUrl;
      return downloadUrl;
    } else {
      throw Exception('QR Image file not found');
    }
  }

  SavingQR(studentID) async {
    String fileName =
        'places/${DateTime.now().millisecondsSinceEpoch.toString()}.jpg';
    FirebaseStorage storage = FirebaseStorage.instance;
    // TaskSnapshot snapshot = await storage.ref(fileName).putFile(_image!);
    // final String downloadUrl = await snapshot.ref.getDownloadURL();
  }

  void _clearFormFields() {
    _emailController.clear();
    _nameController.clear();
    _ageController.clear();
    _addressController.clear();
    _emergencyNumber1Controller.clear();
    _emergencyNumber2Controller.clear();
    _emergencyNumber3Controller.clear();
    _healthConditionController.clear();
  }
}
