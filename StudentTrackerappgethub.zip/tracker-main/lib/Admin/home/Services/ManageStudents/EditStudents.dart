import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class EditStudent extends StatefulWidget {
  final String studentId;
  EditStudent({Key? key, required this.studentId}) : super(key: key);

  @override
  _EditStudentState createState() => _EditStudentState();
}

class _EditStudentState extends State<EditStudent> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _emergencyNumber1Controller =
      TextEditingController();
  final TextEditingController _emergencyNumber2Controller =
      TextEditingController();
  final TextEditingController _emergencyNumber3Controller =
      TextEditingController();
  final TextEditingController _healthConditionController =
      TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _fetchStudentDetails();
  }

  _fetchStudentDetails() async {
    DocumentSnapshot student = await FirebaseFirestore.instance
        .collection('students')
        .doc(widget.studentId)
        .get();
    if (student.exists) {
      Map<String, dynamic> data = student.data() as Map<String, dynamic>;
      _emailController.text = data['email'];
      _nameController.text = data['name'];
      _ageController.text = data['age'];
      _addressController.text = data['address'];
      _emergencyNumber1Controller.text = data['emergencyNumber1'];
      _emergencyNumber2Controller.text = data['emergencyNumber2'];
      _emergencyNumber3Controller.text = data['emergencyNumber3'];
      _healthConditionController.text = data['healthCondition'];
      setState(() {});
    }
  }

  void _updateStudentDetails() async {
    if (_formKey.currentState!.validate()) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (c) => const LoadingAlertDialog(message: "Updating Data..."),
      );

      await FirebaseFirestore.instance
          .collection('students')
          .doc(widget.studentId)
          .update({
        "email": _emailController.text.trim(),
        "name": _nameController.text.trim(),
        "age": _ageController.text.trim(),
        "address": _addressController.text.trim(),
        "emergencyNumber1": _emergencyNumber1Controller.text.trim(),
        "emergencyNumber2": _emergencyNumber2Controller.text.trim(),
        "emergencyNumber3": _emergencyNumber3Controller.text.trim(),
        "healthCondition": _healthConditionController.text.trim(),
      }).then((value) {
        Navigator.pop(context); // Close the loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Student details updated successfully")),
        );
      }).catchError((error) {
        Navigator.pop(context); // Close the loading dialog
        showDialog(
          context: context,
          builder: (_) => ErrorAlertDialog(
            message: "Failed to update student details: $error",
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "Edit Student",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildTextField(_emailController, "Email", Icons.email),
                  _buildTextField(_nameController, "Name", Icons.person),
                  _buildTextField(_ageController, "Age", Icons.calendar_today),
                  _buildTextField(_addressController, "Address", Icons.home),
                  _buildTextField(_emergencyNumber1Controller,
                      "Emergency Number 1", Icons.phone),
                  _buildTextField(_emergencyNumber2Controller,
                      "Emergency Number 2", Icons.phone),
                  _buildTextField(_emergencyNumber3Controller,
                      "Emergency Number 3", Icons.phone),
                  _buildTextField(_healthConditionController,
                      "Health Condition", Icons.local_hospital),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: _updateStudentDetails,
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50))),
                      backgroundColor:
                          MaterialStateProperty.all(TrackerApp.primaryColor),
                    ),
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                      child: Text(
                        "Update Student",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return Container(
      height: 60,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        cursorColor: Colors.black,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
        decoration: InputDecoration(
          hintText: label,
          prefixIcon: Icon(icon, color: TrackerApp.primaryColor),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: TrackerApp.primaryColor),
            borderRadius: BorderRadius.circular(30),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: TrackerApp.primaryColor),
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
    );
  }
}
