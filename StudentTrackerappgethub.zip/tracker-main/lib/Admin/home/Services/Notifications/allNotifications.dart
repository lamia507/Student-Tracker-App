import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/Services/Notifications/Notifications.dart';
import 'package:tracker/Widgets/config/config.dart';

class allNotifications extends StatefulWidget {
  const allNotifications({super.key});

  @override
  State<allNotifications> createState() => _allNotifications();
}

class _allNotifications extends State<allNotifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "All Notifications",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where("type", isNotEqualTo: "admin")
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final recivers = snapshot.data!.docs;
          return ListView.builder(
            itemCount: recivers.length,
            itemBuilder: (context, index) {
              var reciver = recivers[index];
              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: TrackerApp.textFiedlColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        child: Text(reciver['fullName']
                            [0]), // Display first letter of the name
                      ),
                      title: Text(reciver['fullName']),
                      subtitle: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Email: ${reciver['email']}'),
                          Text('Phone Number: ${reciver['phoneNumber']}'),
                        ],
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.chat, color: TrackerApp.primaryColor),
                        onPressed: () {
                          addingChatCollections(
                              reciver.id, reciver['fullName']);
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  addingChatCollections(String reciverID, reciverName) async {
    // This is the Admin ID
    String currentUser = FirebaseAuth.instance.currentUser?.uid ?? "";

    // This is the Admin Name
    String fullName =
        TrackerApp.trmporallyData?.getString("fullName").toString().trim() ??
            "";
    // check if it exisit
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("notifications")
        .where("adminID", isEqualTo: currentUser)
        .where("reciverID", isEqualTo: reciverID)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => AdminNotifications(
            reciverID: querySnapshot.docs[0]['reciverID'],
            reciverName: querySnapshot.docs[0]['reciverName'],
            notificationID: querySnapshot.docs[0].id,
          ),
        ),
      );
    } else {
      await FirebaseFirestore.instance.collection("notifications").add(
        {
          "adminID": currentUser,
          "reciverID": reciverID,
          "adminName": fullName,
          "date": DateTime.now(),
          "reciverName": reciverName,
        },
      ).then((results) {
        var asdf = results.get();
        asdf.then((response) {
          response.data()?['reciverID'];
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AdminNotifications(
                reciverID: response.data()?['reciverID'],
                reciverName: response.data()?['adminName'],
                notificationID: response.id,
              ),
            ),
          );
        });
      });
    }
  }
}
