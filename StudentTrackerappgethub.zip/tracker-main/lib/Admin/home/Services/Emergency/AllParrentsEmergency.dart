import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/Services/Emergency/AdminViewingemergencyCallForStudetns.dart';
import 'package:tracker/Admin/home/Services/wallet/AdminViewingStudentsWallet.dart';
import 'package:tracker/Widgets/config/config.dart';

class AllParrentsEmergency extends StatefulWidget {
  const AllParrentsEmergency({Key? key}) : super(key: key);

  @override
  State<AllParrentsEmergency> createState() => _AllParrentsEmergencyState();
}

class _AllParrentsEmergencyState extends State<AllParrentsEmergency> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "All Parents",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where("type", isEqualTo: "parent")
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final parents = snapshot.data!.docs;

          return ListView.builder(
            itemCount: parents.length,
            itemBuilder: (context, index) {
              var parent = parents[index];
              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: TrackerApp.textFiedlColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        child: Text(parent['fullName']
                            [0]), // Display first letter of the name
                      ),
                      title: Text(parent['fullName']),
                      subtitle: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(parent['email']),
                        ],
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              Route route = MaterialPageRoute(
                                builder: (_) =>
                                    AdminViewingemergencyCallForStudetns(
                                        parentiD: parent.id),
                              );
                              Navigator.push(context, route);
                            },
                            child: const Text("View Emergency"),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  _deleteParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .delete()
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent deleted successfully'),
        ),
      );
    }).catchError((error) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error deleting parent'),
        ),
      );
    });
  }

  _acceptParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .update({'status': 'Accepted'}).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent accepted'),
        ),
      );
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error updating parent status'),
        ),
      );
    });
  }

  _rejectParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .update({'status': 'Rejected'}).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent rejected'),
        ),
      );
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error updating parent status'),
        ),
      );
    });
  }
}
