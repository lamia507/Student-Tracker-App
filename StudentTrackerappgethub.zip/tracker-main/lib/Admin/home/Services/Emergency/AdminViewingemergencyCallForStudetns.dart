import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Parents/home/Services/ManageStudents/EditStudents.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Parents/home/Services/ManageStudents/addStudent.dart';

class AdminViewingemergencyCallForStudetns extends StatefulWidget {
  final String parentiD;
  const AdminViewingemergencyCallForStudetns({Key? key, required this.parentiD})
      : super(key: key);

  @override
  State<AdminViewingemergencyCallForStudetns> createState() =>
      _AdminViewingemergencyCallForStudetnsState();
}

class _AdminViewingemergencyCallForStudetnsState
    extends State<AdminViewingemergencyCallForStudetns> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "Emergency Contacts",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('students')
            .where("parentID", isEqualTo: widget.parentiD)
            .snapshots(), // Removed where("parentID") to fix the query
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final students = snapshot.data!.docs;

          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              var student = students[index].data() as Map<String,
                  dynamic>; // Cast each document to Map<String, dynamic>
              return Card(
                // Using Card for better UI presentation
                margin: const EdgeInsets.all(10),

                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Name: ${student['name']}",
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 1: ${student['emergencyNumber1']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 2: ${student['emergencyNumber2']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 3: ${student['emergencyNumber3']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 20),
                      const Text(
                          "Note: To edit the emergency contacts numbesr, edit it in the student page.")
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _deleteStudent(String studentId) async {
    await FirebaseFirestore.instance
        .collection('students')
        .doc(studentId)
        .delete()
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Student deleted successfully'),
        ),
      );
    }).catchError((error) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error deleting student'),
        ),
      );
    });
  }
}
