import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:tracker/Admin/home/Services/Emergency/AllParrentsEmergency.dart';
import 'package:tracker/Admin/home/Services/Grades/AllStudents.dart';
import 'package:tracker/Admin/home/Services/ManageParents/AdminManageParent.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/viewSellers.dart';
import 'package:tracker/Admin/home/Services/ManageStudents/AllStudentsViewAdmin.dart';
import 'package:tracker/Admin/home/Services/Notifications/allNotifications.dart';
import 'package:tracker/Widgets/config/config.dart';

class AdminServices extends StatefulWidget {
  const AdminServices({super.key});

  @override
  State<AdminServices> createState() => _AdminServicesState();
}

class _AdminServicesState extends State<AdminServices> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: GridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 5,
          children: [
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (context) => const AllStudentsViewAdmin());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      const Text(
                        "Students",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(Icons.school,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (_) => const AllStudentsForGrades());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text("Grade",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.bold)),
                      Icon(Icons.grade,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (_) => const AllParrentsEmergency());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        "Emergency Call",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(Icons.call,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const ViewSellersPage());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text("View Sellers",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.bold)),
                      Icon(Icons.sell,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const ManageAllParent());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text("Manage Parent",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      Icon(Icons.family_restroom,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const allNotifications());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.13), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        "Notifications",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(Icons.notifications,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
