import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class AdminViewingStudentsWallet extends StatefulWidget {
  final String paretnID;
  const AdminViewingStudentsWallet({Key? key, required this.paretnID})
      : super(key: key);

  @override
  State<AdminViewingStudentsWallet> createState() =>
      _AdminViewingStudentsWalletState();
}

class _AdminViewingStudentsWalletState
    extends State<AdminViewingStudentsWallet> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  TextEditingController _MoneyTextEditingController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? validateRange(String? value, {required int min, required int max}) {
    if (value == null || value.isEmpty) {
      return 'Please enter a value';
    }
    final intValue = int.tryParse(value);
    if (intValue == null) {
      return 'Please enter a valid number';
    } else if (intValue <= min) {
      return 'The value must be greater than $min';
    } else if (intValue > max) {
      return 'The value must be $max or less';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "Students Wallet",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('students')
            .where("parentID", isEqualTo: widget.paretnID)
            .snapshots(), // Removed where("parentID") to fix the query
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final students = snapshot.data!.docs;

          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              var student = students[index].data() as Map<String,
                  dynamic>; // Cast each document to Map<String, dynamic>
              String money = student['Money'] ?? "";
              return Card(
                // Using Card for better UI presentation
                margin: const EdgeInsets.all(10),

                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Name: ${student['name']}",
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "${money != "" ? student['Money'] : "0"}SA",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  addingMoney(studentId) async {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text(
          "Adding Money",
          textAlign: TextAlign.center,
        ),
        titlePadding: const EdgeInsets.all(20),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                ValidatingData(studentId);
              },
              child: const Text("Save"),
            ),
          ),
        ],
        content: Form(
          key: _formKey,
          child: TextFormField(
            decoration: const InputDecoration(
              hintText: "100SA",
            ),
            controller: _MoneyTextEditingController,
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a value'; // Ensures the field is not empty
              }
              try {
                final intValue = int.parse(value);
                if (intValue < 100) {
                  return 'The value must be greater than 100'; // Checks if the value is greater than 100
                }
                if (intValue > 1000) {
                  return 'The value must be 1000 or less'; // Ensures the value is 1000 or less
                }
              } on FormatException {
                return 'Please enter a valid number'; // Catches format errors if the input is not a number
              }
              return null; // Indicates the input is valid
            },
          ),
        ),
      ),
    );
  }

  ValidatingData(studentId) async {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context);
      showDialog(
        context: context,
        barrierDismissible: false, // user must tap button!
        builder: (BuildContext context) {
          return const LoadingAlertDialog(
            message: "Adding Money to a student, please wait...",
          );
        },
      );

      await FirebaseFirestore.instance
          .collection('students')
          .doc(studentId)
          .update({
        "Money": _MoneyTextEditingController.text.trim(),
        "AddedOn": DateTime.now(),
      }).then((_) {
        Navigator.pop(context);
        _MoneyTextEditingController.clear();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Money was added successfully'),
          ),
        );
        setState(() {});
      }).catchError((error) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error Adding Money'),
          ),
        );
      });
    }
  }
}
