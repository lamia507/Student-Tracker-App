import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/EditSellers.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/addSellers.dart';
import 'package:tracker/Admin/home/Services/wallet/AdminViewingStudentsWallet.dart';
import 'package:tracker/Widgets/config/config.dart';

class ManageAllParent extends StatefulWidget {
  const ManageAllParent({Key? key}) : super(key: key);

  @override
  State<ManageAllParent> createState() => _ManageAllParentState();
}

class _ManageAllParentState extends State<ManageAllParent> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "All Parents",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where("type", isEqualTo: "parent")
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final parents = snapshot.data!.docs;

          return ListView.builder(
            itemCount: parents.length,
            itemBuilder: (context, index) {
              var parent = parents[index];
              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: TrackerApp.textFiedlColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        child: Text(parent['fullName']
                            [0]), // Display first letter of the name
                      ),
                      title: Text(parent['fullName']),
                      subtitle: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(parent['email']),
                          Text(
                            parent['status'],
                            style: TextStyle(
                              color: parent['status'] == "Accepted"
                                  ? Colors.green
                                  : Colors.red,
                            ),
                          ),
                        ],
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              _deleteParent(parent.id);
                            },
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ElevatedButton(
                            onPressed: () => _acceptParent(parent.id),
                            style: ElevatedButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: Colors.green, // Text color
                              elevation: 3, // Shadow depth
                            ),
                            child: const Text('Accept'),
                          ),
                          const SizedBox(
                              width: 8), // Add some space between the buttons
                          ElevatedButton(
                            onPressed: () => _rejectParent(parent.id),
                            style: ElevatedButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: Colors.red, // Background color

                              elevation: 3, // Shadow depth
                            ),
                            child: const Text('Reject'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  _deleteParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .delete()
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent deleted successfully'),
        ),
      );
    });
  }

  _acceptParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .update({'status': 'Accepted'}).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent accepted'),
        ),
      );
    });
  }

  _rejectParent(String parentID) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(parentID)
        .update({'status': 'Rejected'}).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Parent rejected'),
        ),
      );
    });
  }
}
