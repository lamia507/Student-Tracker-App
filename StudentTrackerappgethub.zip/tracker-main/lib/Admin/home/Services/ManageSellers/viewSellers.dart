import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/EditSellers.dart';
import 'package:tracker/Admin/home/Services/ManageSellers/addSellers.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class ViewSellersPage extends StatefulWidget {
  const ViewSellersPage({Key? key}) : super(key: key);

  @override
  State<ViewSellersPage> createState() => _ViewSellersPageState();
}

class _ViewSellersPageState extends State<ViewSellersPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "View Sellers",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Route route = MaterialPageRoute(builder: (_) => const AddSellers());
          Navigator.push(context, route);
        },
        backgroundColor: TrackerApp.primaryColor,
        child: const Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where("type", isEqualTo: "seller")
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final sellers = snapshot.data!.docs;

          return ListView.builder(
            itemCount: sellers.length,
            itemBuilder: (context, index) {
              var seller = sellers[index];
              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: TrackerApp.textFiedlColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(seller['fullName']
                        [0]), // Display first letter of the name
                  ),
                  title: Text(seller['fullName']),
                  subtitle: Text(seller['email']),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => EditSeller(
                                sellerId: seller
                                    .id), // Pass seller ID to the edit page
                          ));
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteSeller(seller.id),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _deleteSeller(String sellerId) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(sellerId)
        .delete()
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seller deleted successfully'),
        ),
      );
    }).catchError((error) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error deleting seller'),
        ),
      );
    });
  }
}
