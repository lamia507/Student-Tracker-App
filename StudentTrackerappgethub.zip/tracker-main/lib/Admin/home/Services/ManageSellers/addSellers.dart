import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';
import 'package:tracker/Widgets/config/config.dart';

class AddSellers extends StatefulWidget {
  const AddSellers({super.key});

  @override
  State<AddSellers> createState() => _AddSellersState();
}

class _AddSellersState extends State<AddSellers> {
  TextEditingController _email = TextEditingController();
  TextEditingController _fullName = TextEditingController();
  TextEditingController _phoneNumber = TextEditingController();
  TextEditingController _password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Image.asset("images/logo2.png"),
                    Text(
                      "Sellers Tracker",
                      style: TextStyle(
                        color: TrackerApp.primaryColor,
                        fontSize: 22,
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    // Email TextField
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        controller: _email,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Email",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.email,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    // Password TextField
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        controller: _password,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "*************",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.lock,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    // Full Name TextField
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        controller: _fullName,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Full Name",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.person,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    // Phone Number TextField
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        controller: _phoneNumber,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Phone Number",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.phone,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    _validateData();
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(
                      TrackerApp.primaryColor,
                    ),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                    child: Text(
                      "Add Seller",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _validateData() {
    if (_email.text.isNotEmpty &&
        _fullName.text.isNotEmpty &&
        _password.text.isNotEmpty &&
        _phoneNumber.text.isNotEmpty) {
      _savingData();
    } else {
      _displayDialog();
    }
  }

  void _displayDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) {
        return const ErrorAlertDialog(
          message: "Please fill up the information",
        );
      },
    );
  }

  void _savingData() async {
    showDialog(
      context: context,
      builder: (c) {
        return const LoadingAlertDialog(
          message: "Adding Seller, Please Wait...",
        );
      },
    );
    _registerSeller();
  }

  void _registerSeller() async {
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(
            email: _email.text.trim(), password: _password.text.trim())
        .then((auth) {
      _saveSellerInfo(auth.user!.uid);
    }).catchError((error) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (c) => ErrorAlertDialog(
          message: error.toString(),
        ),
      );
    });
  }

  Future _saveSellerInfo(String currentSeller) async {
    await FirebaseFirestore.instance
        .collection("users")
        .doc(currentSeller)
        .set({
      "uid": currentSeller,
      "email": _email.text.trim(),
      "fullName": _fullName.text.trim(),
      "type": "seller",
      "phoneNumber": _phoneNumber.text.trim(),
      "uploadedBy": FirebaseAuth.instance.currentUser?.uid.toString(),
      "registeredTime": DateTime.now(),
    }).then(
      (value) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Seller Was Added Successfully"),
          ),
        );
      },
    );
  }
}
