import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class EditSeller extends StatefulWidget {
  final String sellerId;
  EditSeller({Key? key, required this.sellerId}) : super(key: key);

  @override
  _EditSellerState createState() => _EditSellerState();
}

class _EditSellerState extends State<EditSeller> {
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _fetchSellerDetails();
  }

  _fetchSellerDetails() async {
    DocumentSnapshot seller = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.sellerId)
        .get();
    if (seller.exists) {
      _fullNameController.text = seller['fullName'];
      _phoneNumberController.text = seller['phoneNumber'];
      setState(() {});
    }
  }

  void _updateSellerDetails() async {
    if (_formKey.currentState!.validate()) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (c) => const LoadingAlertDialog(message: "Updating Data..."),
      );

      await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.sellerId)
          .update({
        "fullName": _fullNameController.text.trim(),
        "phoneNumber": _phoneNumberController.text.trim(),
      }).then((value) {
        Navigator.pop(context); // Close the loading dialog
        showDialog(
          context: context,
          builder: (_) => const ErrorAlertDialog(
            message: "Seller details updated successfully",
          ),
        );
      }).catchError((error) {
        Navigator.pop(context); // Close the loading dialog
        showDialog(
          context: context,
          builder: (_) => ErrorAlertDialog(
            message: "Failed to update seller details: $error",
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "Edit Sellers",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // Full Name TextField
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      controller: _fullNameController,
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        hintText: "Full Name",
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                        ),
                        isCollapsed: false,
                        isDense: true,
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        prefixIcon: Icon(
                          Icons.person,
                          color: TrackerApp.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  // Phone Number TextField
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      controller: _phoneNumberController,
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        hintText: "Phone Number",
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                        ),
                        isCollapsed: false,
                        isDense: true,
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        prefixIcon: Icon(
                          Icons.phone,
                          color: TrackerApp.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      _updateSellerDetails();
                    },
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all(
                        TrackerApp.primaryColor,
                      ),
                    ),
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                      child: Text(
                        "Update Seller",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
