import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class AddGrade extends StatefulWidget {
  final String studentId;

  const AddGrade({Key? key, required this.studentId}) : super(key: key);

  @override
  State<AddGrade> createState() => _AddGradeState();
}

class _AddGradeState extends State<AddGrade> {
  final TextEditingController _gradeController = TextEditingController();
  final TextEditingController _semesterController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Semester Grade",
            style: TextStyle(color: Colors.white)),
        backgroundColor: TrackerApp.primaryColor,
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              Container(
                height: 45,
                margin: const EdgeInsets.all(5),
                child: TextField(
                  controller: _semesterController,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    hintText: "Semester (e.g., Fall 2024)",
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xffc8d2d3),
                      ),
                    ),
                    isCollapsed: false,
                    isDense: true,
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1,
                        color: Color(0xffc8d2d3),
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    prefixIcon: Icon(
                      Icons.calendar_today,
                      color: TrackerApp.primaryColor,
                    ),
                  ),
                ),
              ),
              Container(
                height: 45,
                margin: const EdgeInsets.all(5),
                child: TextField(
                  controller: _gradeController,
                  cursorColor: Colors.black,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: "Semester Average Grade (0-100)",
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xffc8d2d3),
                      ),
                    ),
                    isCollapsed: false,
                    isDense: true,
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1,
                        color: Color(0xffc8d2d3),
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    prefixIcon: Icon(
                      Icons.score,
                      color: TrackerApp.primaryColor,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveGrade,
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all(TrackerApp.primaryColor),
                  shape: MaterialStateProperty.all(RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50))),
                ),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                  child: Text(
                    "Add Semester Grade",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveGrade() {
    final String semester = _semesterController.text.trim();
    final double? grade = double.tryParse(_gradeController.text.trim());

    if (semester.isEmpty || grade == null || grade < 0 || grade > 100) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (c) {
          return const ErrorAlertDialog(
            message: "Please fill all the fields correctly",
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (c) {
          return const LoadingAlertDialog(
            message: "Adding Semester Grade, Please Wait...",
          );
        },
      );

      FirebaseFirestore.instance
          .collection('students')
          .doc(widget.studentId)
          .collection('grades')
          .doc(semester)
          .set({
        'semester': semester,
        'averageGrade': grade,
        'timestamp': FieldValue.serverTimestamp(),
      }).then((_) {
        Navigator.pop(context); // Close the loading dialog
        Navigator.pop(context); // Optionally go back after saving
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Semester grade added successfully")),
        );
      }).catchError((error) {
        Navigator.pop(context); // Close the loading dialog
        showDialog(
          context: context,
          builder: (c) => ErrorAlertDialog(
            message: error.toString(),
          ),
        );
      });
    }
  }
}
