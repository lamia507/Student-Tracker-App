import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/Profile/AdminEditProiflePage.dart';
import 'package:tracker/Common/ChoicePage.dart';
import 'package:tracker/Parents/Profile/ParentEditProiflePage.dart';
import 'package:tracker/Parents/contactUS/contact.dart';
import 'package:tracker/Widgets/config/config.dart';

class AdminProfilePage extends StatefulWidget {
  const AdminProfilePage({super.key});

  @override
  State<AdminProfilePage> createState() => _AdminProfilePageState();
}

class _AdminProfilePageState extends State<AdminProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.person,
              size: 100,
            ),
            Text(
              "Admin",
              style: TextStyle(
                color: TrackerApp.primaryColor,
                fontSize: 25,
              ),
            ),
            const Divider(),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => AdminEditProiflePage());
                Navigator.push(context, route);
              },
              child: const ListTile(
                title: Text("Edit Profile"),
                leading: Icon(
                  Icons.edit,
                ),
                trailing: Icon(Icons.arrow_forward),
              ),
            ),
            const Divider(),
            GestureDetector(
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Route route = MaterialPageRoute(
                    builder: (_) => const ChoicePage(),
                  );
                  Navigator.push(context, route);
                });
              },
              child: const ListTile(
                title: Text("Log out"),
                leading: Icon(
                  Icons.logout,
                ),
                trailing: Icon(Icons.arrow_forward),
              ),
            ),
            const Divider(),
          ],
        ),
      ),
    );
  }
}
