// استيراد مكتبة Firestore من Firebase للتعامل مع قواعد البيانات السحابية.
import 'package:cloud_firestore/cloud_firestore.dart';
// استيراد مكتبة FirebaseAuth للتعامل مع عمليات التوثيق في Firebase.
import 'package:firebase_auth/firebase_auth.dart';
// استيراد مكتبة المواد في Flutter لاستخدام عناصر واجهة المستخدم المادية.
import 'package:flutter/material.dart';
import 'package:tracker/Common/resetPassword.dart';
// استيراد الملف الخاص بعرض حوار الخطأ من مجلد Widgets.
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
// استيراد الملف الخاص بعرض حوار التحميل من مجلد Widgets.
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';
// استيراد الملف الخاص بصفحة تسجيل الدخول من مجلد Common.
import 'package:tracker/Common/login.dart';
// استيراد الملف الخاص بإعادة تعيين كلمة المرور من مجلد Authentication.
// استيراد الملف الخاص بالتكوينات من مجلد Widgets.
import 'package:tracker/Widgets/config/config.dart';

// تعريف كلاس AdminRegister الذي يرث من StatefulWidget لإنشاء واجهة تسجيل الإداريين.
class AdminRegister extends StatefulWidget {
  // البناء الأساسي للكلاس وتمرير المفتاح للكلاس الأساسي.
  const AdminRegister({super.key});

  @override
  // تعريف الدالة createState لإنشاء الحالة المرتبطة بالواجهة.
  State<AdminRegister> createState() => _AdminRegisterState();
}

// تعريف الحالة _AdminRegisterState الخاصة بكلاس AdminRegister.
class _AdminRegisterState extends State<AdminRegister> {
  // تعريف TextEditingController لإدارة حقل البريد الإلكتروني.
  final TextEditingController _email = TextEditingController();
  // تعريف TextEditingController لإدارة حقل الاسم الكامل.
  final TextEditingController _fullName = TextEditingController();
  // تعريف TextEditingController لإدارة حقل رقم الهاتف.
  final TextEditingController _phneNumber = TextEditingController();
  // تعريف TextEditingController لإدارة حقل كلمة المرور.
  final TextEditingController _password = TextEditingController();

  @override
  // تعريف الدالة build لبناء واجهة المستخدم للتسجيل.
  Widget build(BuildContext context) {
    return Scaffold(
      // إنشاء شريط التطبيق.
      appBar: AppBar(),
      // إنشاء جسم الواجهة ضمن منطقة آمنة.
      body: SafeArea(
        // استخدام SingleChildScrollView للسماح بالتمرير إذا كان المحتوى أكبر من الشاشة.
        child: SingleChildScrollView(
          // استخدام حاوية لتنظيم المحتوى.
          child: Container(
            // تحديد الهوامش الداخلية للحاوية.
            padding: const EdgeInsets.all(10),
            // استخدام عمود لتنظيم العناصر رأسيًا.
            child: Column(
              // تحديد المحاذاة الرئيسية للعناصر داخل العمود.
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              // تعريف العناصر داخل العمود.
              children: [
                // استخدام عمود آخر لتنظيم عناصر الشعار ونص التطبيق.
                Column(
                  children: [
                    // عرض شعار التطبيق.
                    Image.asset("images/logo2.png"),
                    // عرض نص التطبيق مع تحديد النمط.
                    Text(
                      "Students Tracker",
                      style: TextStyle(
                        // تحديد لون النص من التكوينات.
                        color: TrackerApp.primaryColor,
                        // تحديد حجم النص.
                        fontSize: 22,
                      ),
                    ),
                  ],
                ),
                // استخدام عمود لتنظيم حقول الإدخال.
                Column(
                  children: [
                    // استخدام حاوية لتنظيم حقل البريد الإلكتروني.
                    Container(
                      // تحديد ارتفاع الحاوية.
                      height: 45,
                      // تحديد الهوامش الخارجية للحاوية.
                      margin: const EdgeInsets.all(5),
                      // استخدام TextField لإدخال البريد الإلكتروني.
                      child: TextField(
                        // تعطيل النص المخفي لعرض البريد الإلكتروني.
                        obscureText: false,
                        // تحديد المتحكم لحقل البريد الإلكتروني.
                        controller: _email,
                        // تحديد لون المؤشر.
                        cursorColor: Colors.black,
                        // تحديد تزيين حقل الإدخال.
                        decoration: InputDecoration(
                          // تحديد نص الإرشاد.
                          hintText: "Email",
                          // تحديد حدود الحقل عند التركيز.
                          focusedBorder: const OutlineInputBorder(
                            // تحديد نمط ولون الحدود.
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          // تحديد الانهيار.
                          isCollapsed: false,
                          // تحديد الكثافة.
                          isDense: true,
                          // تحديد حدود الحقل عند التمكين.
                          enabledBorder: OutlineInputBorder(
                            // تحديد نمط ولون الحدود.
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            // تحديد الزوايا الدائرية للحدود.
                            borderRadius: BorderRadius.circular(30),
                          ),
                          // تحديد الأيقونة البادئة.
                          prefixIcon: Icon(
                            // تحديد أيقونة البريد الإلكتروني.
                            Icons.email,
                            // تحديد لون الأيقونة من التكوينات.
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    // استخدام حاوية لتنظيم حقل كلمة المرور.
                    Container(
                      // تحديد ارتفاع الحاوية.
                      height: 45,
                      // تحديد الهوامش الخارجية للحاوية.
                      margin: const EdgeInsets.all(5),
                      // استخدام TextField لإدخال كلمة المرور.
                      child: TextField(
                        // تمكين النص المخفي لإخفاء كلمة المرور.
                        obscureText: true,
                        // تحديد المتحكم لحقل كلمة المرور.
                        controller: _password,
                        // تحديد لون المؤشر.
                        cursorColor: Colors.black,
                        // تحديد تزيين حقل الإدخال.
                        decoration: InputDecoration(
                          // تحديد نص الإرشاد.
                          hintText: "********",
                          // تحديد حدود الحقل عند التركيز.
                          focusedBorder: const OutlineInputBorder(
                            // تحديد نمط ولون الحدود.
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          // تحديد الانهيار.
                          isCollapsed: false,
                          // تحديد الكثافة.
                          isDense: true,
                          // تحديد حدود الحقل عند التمكين.
                          enabledBorder: OutlineInputBorder(
                            // تحديد نمط ولون الحدود.
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            // تحديد الزوايا الدائرية للحدود.
                            borderRadius: BorderRadius.circular(30),
                          ),
                          // تحديد الأيقونة البادئة.
                          prefixIcon: Icon(
                            // تحديد أيقونة القفل.
                            Icons.lock,
                            // تحديد لون الأيقونة من التكوينات.
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),

                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _fullName,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Full Name",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.person,
                            color: TrackerApp.primaryColor, //
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _phneNumber,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "054343244",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.phone,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        TextButton(
                          onPressed: () {
                            Route route = MaterialPageRoute(
                                builder: (_) => const RestPassword());
                            Navigator.push(context, route);
                          },
                          child: const Text("Forget Password?"),
                        ),
                      ],
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    ValidateData();
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(50), // Rounded corners
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(
                      const Color(0xffc8d2d3),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 45, vertical: 10),
                    child: Text(
                      "AdminRegister",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: TrackerApp.primaryColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ValidateData() {
    _email.text.isNotEmpty &&
            _fullName.text.isNotEmpty &&
            _password.text.isNotEmpty &&
            _phneNumber.text.isNotEmpty
        ? SavingData()
        : displayDialog();
  }

  displayDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) {
        return const ErrorAlertDialog(
          message: "Please Fill up the Information",
        );
      },
    );
  }

  SavingData() async {
    showDialog(
      context: context,
      builder: (c) {
        return const LoadingAlertDialog(
          message: "Saving Data, Please Wait...",
        );
      },
    );
    _AdminRegistering();
  }

  void _AdminRegistering() async {
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(
            email: _email.text.trim(), password: _password.text.trim())
        .then((auth) {
      saveUserInfo(auth.user!.uid);
    }).catchError((error) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (c) => ErrorAlertDialog(
          message: error.toString(),
        ),
      );
    });
  }

  Future saveUserInfo(String currentUser) async {
    await FirebaseFirestore.instance.collection("users").doc(currentUser).set({
      "uid": currentUser,
      "email": _email.text.trim(),
      "fullName": _fullName.text.trim(),
      "type": "admin",
      "phoneNumber": _phneNumber.text.trim(),
      "RegistredTime": DateTime.now(),
    }).then((value) {
      Route route = MaterialPageRoute(builder: (context) => const Login());
      Navigator.pushReplacement(context, route);
    });
  }
}
