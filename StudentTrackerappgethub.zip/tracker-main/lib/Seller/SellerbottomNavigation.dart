import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Common/ChoicePage.dart';
import 'package:tracker/Seller/SellerHomePage.dart';
import 'package:tracker/Seller/Profile/SellerProfilePage.dart';
import 'package:tracker/Seller/SellerServices.dart';
import 'package:tracker/Widgets/config/config.dart';

class SellerbottomNavigation extends StatefulWidget {
  const SellerbottomNavigation({super.key});

  @override
  State<SellerbottomNavigation> createState() => _SellerbottomNavigation();
}

class _SellerbottomNavigation extends State<SellerbottomNavigation> {
  int currentIndex = 0;
  final List<Widget> pages = [
    const SellerHomePage(),
    const SellerServices(),
    const SellerProfilePage(),
  ];

  final List<String> titles = [
    "Home",
    "Service",
    "Profile Information",
  ];

  void _updatingIndex(int newSelectedIndex) {
    setState(() {
      currentIndex = newSelectedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          titles[currentIndex],
          style: const TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: TrackerApp.primaryColor,
        // actions: [
        //   IconButton(
        //     onPressed: () {
        //       FirebaseAuth.instance.signOut().then((value) {
        //         Route route =
        //             MaterialPageRoute(builder: (_) => const ChoicePage());
        //         Navigator.pushAndRemoveUntil(context, route, (route) => false);
        //       });
        //     },
        //     icon: const Icon(Icons.logout),
        //     color: Colors.white,
        //   ),
        // ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home), // Valid icon
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.build), // Valid icon
            label: "Service",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle), // Valid icon
            label: "Profile",
          ),
        ],
        onTap: _updatingIndex,
        currentIndex: currentIndex,
        showUnselectedLabels: true,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black54,
        backgroundColor: TrackerApp.primaryColor,
        type: BottomNavigationBarType.fixed,
      ),
      body: pages.elementAt(currentIndex),
    );
  }
}
