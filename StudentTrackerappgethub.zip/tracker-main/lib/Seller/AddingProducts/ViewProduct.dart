import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewProduct extends StatefulWidget {
  final String productID;

  const ViewProduct({Key? key, required this.productID}) : super(key: key);

  @override
  _ViewProductState createState() => _ViewProductState();
}

class _ViewProductState extends State<ViewProduct> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.productID),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("products")
            .where("productID", isEqualTo: widget.productID)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('Product not found'));
          }

          var productData =
              snapshot.data!.docs[0].data() as Map<String, dynamic>;
          return SingleChildScrollView(
            child: showingProductData(context, productData),
          );
        },
      ),
    );
  }
}

Widget showingProductData(BuildContext context, Map<String, dynamic> data) {
  return Padding(
    padding: const EdgeInsets.all(20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: Image.network(
            data['productImage'],
            width: MediaQuery.of(context).size.width * 0.8,
            height: 250,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: 24),
        Text(
          "Product Name: ${data['ProductName']}",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Theme.of(context).primaryColor,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "Product ID: ${data['productID']}",
          style: const TextStyle(fontSize: 18, color: Colors.grey),
        ),
        const SizedBox(height: 8),
        Text(
          "Product Price: ${data['productPrice']} SR",
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 20),
        const Text(
          "Ingredients:",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        // Checking for null or empty list of ingredients
        if (data['ProductIngredients'] != null &&
            (data['ProductIngredients'] as List).isNotEmpty)
          ...((data['ProductIngredients'] as List).map<Widget>((ingredient) {
            return Padding(
              padding: const EdgeInsets.only(top: 4.0, bottom: 4.0),
              child: Text(
                "- $ingredient",
                style: const TextStyle(fontSize: 16),
              ),
            );
          }).toList()),
        if (data['ProductIngredients'] == null ||
            (data['ProductIngredients'] as List).isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 4.0, bottom: 4.0),
            child: Text(
              "No ingredients listed",
              style: TextStyle(fontSize: 16),
            ),
          ),
      ],
    ),
  );
}
