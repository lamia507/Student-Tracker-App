import 'package:barcode_scan2/barcode_scan2.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tracker/Seller/AddingProducts/ViewProduct.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'addProduct.dart';

class ProductsList extends StatefulWidget {
  @override
  _ProductsListState createState() => _ProductsListState();
}

class _ProductsListState extends State<ProductsList> {
  final TextEditingController searchController = TextEditingController();
  late Stream<QuerySnapshot> productStream;
  String scannedBarcode = "No Barcode";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          scanBarcode();
        },
        backgroundColor: TrackerApp.primaryColor,
        child: const Icon(
          Icons.production_quantity_limits,
          color: Colors.white,
        ),
      ),
      appBar: AppBar(
        title: const Text(
          "Product List",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: TrackerApp.primaryColor,
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                obscureText: false,
                controller: searchController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  hintText: "Search for a product",
                  fillColor: Colors.white,
                  filled: true,
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      width: 2,
                      color: TrackerApp.primaryColor,
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1,
                      color: Color(0xffc8d2d3),
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  prefixIcon: Icon(
                    Icons.search,
                    size: 20,
                    color: TrackerApp.primaryColor,
                  ),
                ),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection("products")
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Text("Error: ${snapshot.error}");
                  } else {
                    final products = snapshot.data!.docs;

                    return GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.8, // Adjusted for larger images
                        mainAxisSpacing: 10.0,
                        crossAxisSpacing: 10.0,
                      ),
                      itemCount: products.length,
                      itemBuilder: (context, index) {
                        final product = products[index];
                        final productName = product["ProductName"];
                        final productImage = product["productImage"];
                        final productPrice = product[
                            "productPrice"]; // Assuming price field exists
                        String productID = product['productID'];
                        String ProductUID = product.id;

                        return Card(
                          // Use Card for better elevation and shadow
                          elevation: 4.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            children: [
                              Expanded(
                                flex: 2, // Gives more space to the image
                                child: ClipRRect(
                                  borderRadius: const BorderRadius.vertical(
                                      top: Radius.circular(10.0)),
                                  child: Image.network(
                                    productImage,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  productName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14.0,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 4.0),
                                child: Text(
                                  "\$$productPrice",
                                  style: const TextStyle(
                                    fontSize: 16.0,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                              ButtonBar(
                                alignment: MainAxisAlignment.center,
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      Route route = MaterialPageRoute(
                                        builder: (_) => ViewProduct(
                                          productID: productID,
                                        ),
                                      );
                                      Navigator.push(context, route);
                                    },
                                    icon: const Icon(
                                      Icons.remove_red_eye_rounded,
                                      color: Colors.blue,
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      deleteProduct(ProductUID);
                                    },
                                    icon: const Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> scanBarcode() async {
    try {
      var result = await BarcodeScanner.scan();
      if (result.rawContent.isNotEmpty) {
        setState(() {
          scannedBarcode =
              result.rawContent; // Use the scanned barcode value as the ID.
        });
        Route route = MaterialPageRoute(
          builder: (_) => AddProduct(
            productID: scannedBarcode,
          ),
        );
        Navigator.push(context, route);
      }
    } catch (e) {
      // Handle errors here, such as when the user cancels the scan or if there's an issue with the camera.
      print('Error scanning barcode: $e');
    }
  }

  deleteProduct(String productUID) async {
    await FirebaseFirestore.instance
        .collection("products")
        .doc(productUID)
        .delete()
        .then(
      (value) {
        showDialog(
          context: context,
          builder: (_) => const ErrorAlertDialog(
            message:
                "Product Was Deleted Successfully", // Show an error dialog with the error message.
          ),
        );
      },
    );
  }
}
