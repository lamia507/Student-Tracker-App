import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart' as DateTimeFormating;
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class AddProduct extends StatefulWidget {
  String productID;

  AddProduct({super.key, required this.productID});
  @override
  _AddProductState createState() => _AddProductState();
}

class _AddProductState extends State<AddProduct> {
  TextEditingController productName =
      TextEditingController(); // Controller for name input.
  TextEditingController price =
      TextEditingController(); // Controller for name input.

  TextEditingController ingredientsController = TextEditingController();
  // For Images
  String ProductImageUrl = "";
  XFile? ProductImageFile;

  List<String> ingredients = [];
  final ImagePicker _picker = ImagePicker();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Add Product",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        backgroundColor: TrackerApp.primaryColor,
      ),

      // SafeArea widget ensures content is displayed within safe areas of the screen.
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 30),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                ProductImage();
                              },
                              child: CircleAvatar(
                                radius: 40,
                                child: ProductImageFile != null
                                    ? Image.file(
                                        File(ProductImageFile!.path),
                                      )
                                    : const Icon(
                                        Icons.image,
                                        size: 50,
                                      ),
                              ),
                            ),
                          ],
                        ),
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            child: SizedBox(
                              height: 50,
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.black38,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 12),
                                      child: ProductImageFile != null
                                          ? Text(ProductImageFile!.name)
                                          : const Text("Product Registration"),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Text("Product ID"), // Display the label "Name".

                        Center(
                          child: SizedBox(
                            height: 50,
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.black38,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(3),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                      padding: const EdgeInsets.only(left: 12),
                                      child: Text(widget.productID)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text("Product Name"), // Display the label "Name".

                        // TextField widget for entering a name.
                        TextField(
                          controller: productName,
                          decoration: const InputDecoration(
                            isDense: true,
                            hintText: 'Coffee', // Display a hint text.
                            border: OutlineInputBorder(
                              gapPadding: 30,
                              borderSide: BorderSide(
                                color: Colors.black,
                                width: 3,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text("Ingredients"), // Display the label "Email".
                        // TextField widget for entering an email address.
                        TextField(
                          controller: ingredientsController,
                          decoration: const InputDecoration(
                            isDense: true,
                            hintText:
                                'Milk, Bread, Soysauce', // Display a hint text.
                            border: OutlineInputBorder(
                              gapPadding: 30,
                              borderSide: BorderSide(
                                color: Colors.black,
                                width: 3,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text("Price"), // Display the label "Email".
                        // TextField widget for entering an email address.
                        TextField(
                          controller: price,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            isDense: true,

                            hintText: '10', // Display a hint text.
                            border: OutlineInputBorder(
                              gapPadding: 30,
                              borderSide: BorderSide(
                                color: Colors.black,
                                width: 3,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  // ElevatedButton for triggering the registration process.
                                  ElevatedButton(
                                    onPressed: () {
                                      checkIfProductExisit();
                                    },
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 15),
                                    ),
                                    child: const Text(
                                      "Save Product",
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  } // Define a function named 'register' that takes email, password, context, name, gender, age, question, and allergies as parameters.

  ProductImage() async {
    ProductImageFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      ProductImageFile;
    });
  }

  checkIfProductExisit() async {
    if (widget.productID.isNotEmpty) {
      var data = await FirebaseFirestore.instance
          .collection("products")
          .where("productID", isEqualTo: widget.productID)
          .get();

      if (data.docs.isNotEmpty) {
        String productID = data.docs[0].data()['productID'];
        if (productID == widget.productID) {
          showDialog(
            context: context,
            builder: (_) =>
                const ErrorAlertDialog(message: "Product ID already Exists"),
          );
        } else {
          validateData();
        }
      } else {
        validateData();
      }
    }
  }

  validateData() {
    setState(() {
      ingredients = ingredientsController.text.split(',');
    });
    productName.text.isNotEmpty &&
            ingredientsController.text.isNotEmpty &&
            ProductImageFile!.path.isNotEmpty &&
            price.text.isNotEmpty
        ? SaveImage()
        : showDialog(
            context: context,
            builder: (_) => const ErrorAlertDialog(
              message: "Please Fill up the form",
            ),
          );
  }

  SaveImage() async {
    if (ProductImageFile != null) {
      showDialog(
        context: context,
        builder: (_) =>
            const LoadingAlertDialog(message: "Uploading Product..."),
      ); // Show a custom loading dialog with a validation message.
      String imageName = DateTime.now().microsecondsSinceEpoch.toString();
      Reference reference =
          FirebaseStorage.instance.ref().child("products").child(imageName);
      UploadTask uploadTask = reference.putFile(
        File(ProductImageFile!.path),
      );
      TaskSnapshot taskSnapshot = await uploadTask.whenComplete(() {});
      await taskSnapshot.ref.getDownloadURL().then((ImageUrl) {
        ProductImageUrl = ImageUrl;
      });
    }
    UploadProduct();
  }

  UploadProduct() async {
    String? currentUser = FirebaseAuth.instance.currentUser?.uid;
    await FirebaseFirestore.instance.collection("products").add({
      "ProductName": productName.text.trim(),
      "ProductIngrdiants": ingredients,
      "status": "active",
      "productImage": ProductImageUrl,
      "uploadedBy": currentUser,
      "productPrice": price.text.trim(),
      "productID": widget.productID,
      "DateTime": DateTimeFormating.DateFormat("MM-dd-yyyy")
          .format(DateTime.now())
          .trim()
          .toString(),
    }).then((value) {
      setState(() {
        productName.text = "";
        ingredientsController.text = "";
      });
      Navigator.pop(context);
    });
  }
}
