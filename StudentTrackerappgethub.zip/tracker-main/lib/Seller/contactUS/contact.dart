import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsPage extends StatelessWidget {
  final String email = 'admin@gmail.com';
  final String phoneNumber = '9200';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Us'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Get in touch with our team for assistance or inquiries about the Student Tracker Application.',
              style: TextStyle(fontSize: 18.0),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Email us at:'),
              subtitle: Text(email),
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: const Text('For immediate support, call:'),
              subtitle: Text(phoneNumber),
            ),
            // Additional information about the application could go here
          ],
        ),
      ),
    );
  }
}
