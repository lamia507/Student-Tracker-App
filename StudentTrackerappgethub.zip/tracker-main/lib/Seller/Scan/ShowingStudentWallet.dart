import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class ShowingStudentWallet extends StatefulWidget {
  String StudentID;
  ShowingStudentWallet({Key? key, required this.StudentID}) : super(key: key);

  @override
  State<ShowingStudentWallet> createState() => _ShowingStudentWalletState();
}

class _ShowingStudentWalletState extends State<ShowingStudentWallet> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  final TextEditingController _MoneyTextEditingController =
      TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String name = "";
  String price = "";

  @override
  void initState() {
    gettingData();
    super.initState();
  }

  gettingData() async {
    await FirebaseFirestore.instance
        .collection('students')
        .doc(widget.StudentID)
        .get()
        .then((results) {
      setState(() {
        name = results['name'];
        price = results['Money'];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          " Wallet",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Flexible(
            child: ListView(
              shrinkWrap: true,
              children: [
                Card(
                  margin: const EdgeInsets.all(10),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Name: $name",
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            price == ""
                                ? const Text(
                                    "0",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.green,
                                    ),
                                  )
                                : Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      "${price}SA",
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green,
                                      ),
                                    ),
                                  )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        price == ""
                            ? const Text(
                                "Note: 0 Means no money was added to the studnets or the studnet balance is empty.")
                            : Container()
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('products').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final products = snapshot.data!.docs;
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: products.length,
                  itemBuilder: (context, index) {
                    final product = products[index];
                    return Card(
                      margin: const EdgeInsets.all(8),
                      child: ListTile(
                        leading:
                            Image.network(product['productImage'], width: 50),
                        title: Text(product['ProductName']),
                        subtitle: Text("${product['productPrice']}SA"),
                        trailing: ElevatedButton(
                          onPressed: () {
                            buyingItem(product);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                          child: const Text('Select'),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  buyingItem(QueryDocumentSnapshot<Object?> product) async {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Center(
          child: Text("Confirm Product?"),
        ),
        contentPadding: const EdgeInsets.all(10),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(context);
                int productPrice = int.parse(product['productPrice']);
                showDialog(
                  context: context,
                  builder: (_) => const LoadingAlertDialog(
                    message: "Updating Price",
                  ),
                );
                await FirebaseFirestore.instance
                    .collection('students')
                    .doc(widget.StudentID)
                    .update(
                  {"Money": "${int.parse(price) - productPrice}"},
                ).then((value) async {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Item was Successfully Bought')));
                  // await FirebaseFirestore.instance
                  //     .collection("historyBuying")
                  //     .add({
                  //   "ProductName": product['ProductName'],
                  //   "ProductIngrdiants": product['ProductIngrdiants'],
                  //   "productImage": product['productImage'],
                  //   "SoldBy": currentUser,
                  //   "SoldTo": widget.StudentID,
                  //   "StudnetName": name,
                  //   "productPrice": product['productPrice'],
                  //   "productID": product['productID'],
                  // });
                });
              },
              child: const Text("Yes"),
            ),
            const SizedBox(
              width: 10,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("No"),
            ),
          ],
        ),
        titlePadding: const EdgeInsets.all(10),
      ),
    );
  }
}
