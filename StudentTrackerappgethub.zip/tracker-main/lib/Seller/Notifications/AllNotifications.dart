import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tracker/Admin/chat/AdminChat.dart';
import 'package:tracker/Seller/Notifications/Notifications.dart';
import 'package:tracker/Widgets/config/config.dart';

class AllSellerNotifications extends StatefulWidget {
  const AllSellerNotifications({super.key});

  @override
  State<AllSellerNotifications> createState() => _AllSellerNotifications();
}

class _AllSellerNotifications extends State<AllSellerNotifications> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "All Notifications",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('notifications')
              .where("reciverID", isEqualTo: currentUser)
              .snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final chats = snapshot.data!.docs;

            return ListView.builder(
              itemCount: chats.length,
              itemBuilder: (context, index) {
                var chat = chats[index];
                // Accessing data from the chat document
                String adminID = chat['adminID'];
                String reciverName = chat['reciverName'];
                String adminName = chat['adminName'];

                bool newMessage = chat['newMessage'] ?? false;

                // Formatting the date
                DateTime date = (chat['date'] as Timestamp).toDate();
                String formattedDate =
                    DateFormat.yMMMMd().add_jms().format(date);

                return Container(
                  margin: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: newMessage
                        ? Colors.blue[100]
                        : TrackerApp.textFiedlColor,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text(adminName[0]),
                    ),
                    title: Text(adminName),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Date: $formattedDate'),
                      ],
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.chat, color: TrackerApp.primaryColor),
                      onPressed: () {
                        Route route = MaterialPageRoute(
                            builder: (_) => SellerNotifications(
                                  adminID: adminID,
                                  adminName: adminName,
                                  chatID: chat.id,
                                ));
                        Navigator.push(context, route);
                      },
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  addingChatCollections(String id, adminName) async {
    String currentUser = FirebaseAuth.instance.currentUser?.uid ?? "";
    // check if it exisit
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("chats")
        .where("adminID", isEqualTo: id)
        .where("reciverID", isEqualTo: currentUser)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SellerNotifications(
            adminID: querySnapshot.docs[0]['adminID'],
            adminName: querySnapshot.docs[0]['adminName'],
            chatID: querySnapshot.docs[0].id,
          ),
        ),
      );
      // } else {
      //   await FirebaseFirestore.instance.collection("notifications").add(
      //     {
      //       "adminID": id,
      //       "reciverID": currentUser,
      //       "date": DateTime.now(),
      //       "adminName": adminName,
      //       "newMessage": false,
      //     },
      //   ).then((results) {
      //     var asdf = results.get();
      //     asdf.then((response) {
      //       response.data()?['reciverID'];
      //       Navigator.push(
      //         context,
      //         MaterialPageRoute(
      //           builder: (context) => ChatPage(
      //             adminID: response.data()?['adminID'],
      //             adminName: response.data()?['adminName'],
      //             chatID: response.id,
      //           ),
      //         ),
      //       );
      //     });
      //   });
      // }
    }
  }
}
