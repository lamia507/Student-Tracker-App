import 'package:flutter/material.dart';
import 'package:tracker/Seller/AddingProducts/AllProducts.dart';
import 'package:tracker/Seller/Notifications/AllNotifications.dart';
import 'package:tracker/Seller/Scan/ScanQrCode.dart';
import 'package:tracker/Widgets/config/config.dart';

class SellerServices extends StatefulWidget {
  const SellerServices({super.key});

  @override
  State<SellerServices> createState() => _SellerServicesState();
}

class _SellerServicesState extends State<SellerServices> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: GridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 5,
          children: [
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(builder: (_) => ProductsList());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Expanded(
                        child: Text(
                          "All Products",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Icon(
                        Icons.food_bank,
                        color: TrackerApp.primaryColor,
                        size: 60,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const QRScanPage());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Expanded(
                        child: Text(
                          "Scan",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Icon(
                        Icons.qr_code,
                        color: TrackerApp.primaryColor,
                        size: 60,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (_) => const AllSellerNotifications());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        "Notifications",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(Icons.notifications,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
