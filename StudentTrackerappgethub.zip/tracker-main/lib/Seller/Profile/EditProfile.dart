import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class SellerEditProiflePage extends StatefulWidget {
  @override
  _SellerEditProiflePageState createState() => _SellerEditProiflePageState();
}

class _SellerEditProiflePageState extends State<SellerEditProiflePage> {
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _emailTextEditingController =
      TextEditingController();
  final TextEditingController _fullNameTextEditingController =
      TextEditingController();
  final TextEditingController _phoneNumberTextEditingController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    gettingData();
  }

  Future<void> gettingData() async {
    FirebaseFirestore.instance
        .collection("users")
        .doc(currentUser)
        .get()
        .then((results) {
      _emailTextEditingController.text = results.get('email');
      _fullNameTextEditingController.text = results.get('fullName');
      _phoneNumberTextEditingController.text = results.get('phoneNumber');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(15),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      obscureText: false,
                      controller: _emailTextEditingController,
                      decoration: InputDecoration(
                        enabled: false,
                        isCollapsed: false,
                        isDense: true,
                        prefixIcon: Icon(
                          Icons.email,
                          color: TrackerApp.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      obscureText: false,
                      controller: _fullNameTextEditingController,
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        hintText: "Full Name",
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                        ),
                        isCollapsed: false,
                        isDense: true,
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        prefixIcon: Icon(
                          Icons.person,
                          color: TrackerApp.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      obscureText: false,
                      controller: _phoneNumberTextEditingController,
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        hintText: "Phone Number",
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                        ),
                        isCollapsed: false,
                        isDense: true,
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        prefixIcon: Icon(
                          Icons.phone,
                          color: TrackerApp.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: updateSellerProfile,
                    child: const Text('Update Profile'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> updateSellerProfile() async {
    if (_formKey.currentState!.validate()) {
      showDialog(
        context: context,
        builder: (c) {
          return const LoadingAlertDialog(
            message: "Updating Data...",
          );
        },
      );

      FirebaseFirestore.instance.collection("users").doc(currentUser).update({
        'email': _emailTextEditingController.text.trim(),
        'fullName': _fullNameTextEditingController.text.trim(),
        'phoneNumber': _phoneNumberTextEditingController.text.trim(),
      }).then((_) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Profile updated successfully")),
        );
      }).catchError((error) {
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (c) {
            return ErrorAlertDialog(
              message: "Failed to update profile: $error",
            );
          },
        );
      });
    }
  }
}
