import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:tracker/Admin/Authentication/AdminRegister.dart';
import 'package:tracker/Common/login.dart';
import 'package:tracker/Parents/Authentication/ParentRegister.dart';
import 'package:tracker/Widgets/config/config.dart';

class ChoicePage extends StatefulWidget {
  const ChoicePage({super.key});

  @override
  State<ChoicePage> createState() => _ChoicePageState();
}

class _ChoicePageState extends State<ChoicePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Image.asset("images/logo2.png"),
                  ],
                ),
                Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Route route = MaterialPageRoute(
                            builder: (context) => const AdminRegister());
                        Navigator.push(context, route);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 60,
                        ),
                        decoration: BoxDecoration(
                          color: Colors
                              .white, // Background color for the container
                          borderRadius: BorderRadius.circular(
                            30,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(
                                  0.15), // Shadow color with some transparency
                              spreadRadius:
                                  0, // Extend the shadow to all sides by 1 unit
                              blurRadius:
                                  5, // The higher the blur radius, the more spread out the shadow
                              offset: const Offset(
                                  0, 3), // Position of the shadow (x, y)
                            ),
                          ],
                        ),
                        child: Text(
                          "Admin",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    GestureDetector(
                      onTap: () {
                        Route route = MaterialPageRoute(
                            builder: (context) => const ParentRegister());
                        Navigator.push(context, route);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 60,
                        ),
                        decoration: BoxDecoration(
                          color: Colors
                              .white, // Background color for the container
                          borderRadius: BorderRadius.circular(
                            30,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(
                                  0.15), // Shadow color with some transparency
                              spreadRadius:
                                  0, // Extend the shadow to all sides by 1 unit
                              blurRadius:
                                  5, // The higher the blur radius, the more spread out the shadow
                              offset: const Offset(
                                  0, 3), // Position of the shadow (x, y)
                            ),
                          ],
                        ),
                        child: Text(
                          "Parent",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    GestureDetector(
                      onTap: () {
                        Route route = MaterialPageRoute(
                            builder: (context) => const Login());
                        Navigator.push(context, route);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 60,
                        ),
                        decoration: BoxDecoration(
                          color: Colors
                              .white, // Background color for the container
                          borderRadius: BorderRadius.circular(
                            30,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(
                                  0.15), // Shadow color with some transparency
                              spreadRadius:
                                  0, // Extend the shadow to all sides by 1 unit
                              blurRadius:
                                  5, // The higher the blur radius, the more spread out the shadow
                              offset: const Offset(
                                  0, 3), // Position of the shadow (x, y)
                            ),
                          ],
                        ),
                        child: Text(
                          "Login",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
