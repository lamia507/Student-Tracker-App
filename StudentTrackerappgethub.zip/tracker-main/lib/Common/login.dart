import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Admin/home/bottomNavigationAdmin.dart';
import 'package:tracker/Common/resetPassword.dart';
import 'package:tracker/Parents/home/CustomBottomNavigationParent.dart';
import 'package:tracker/Seller/SellerbottomNavigation.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';
import 'package:tracker/Widgets/config/config.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController _email = TextEditingController();
  TextEditingController _password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Image.asset("images/logo2.png"),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _email,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Email",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.email, // Email icon
                            color: TrackerApp.primaryColor, // Icon color
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: true,
                        controller: _password,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "********",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.lock, // Email icon
                            color: TrackerApp.primaryColor, // Icon color
                          ),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            TextButton(
                              onPressed: () {
                                Route route = MaterialPageRoute(
                                  builder: (_) => const RestPassword(),
                                );
                                Navigator.push(context, route);
                              },
                              child: const Text("Forget Password?"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                ElevatedButton(
                  // When it's clicked,
                  onPressed: () {
                    ValidateData();
                  },
                  style: ButtonStyle(
                    // Custom style for the button
                    shape: MaterialStateProperty.all(
                      // Shape of the button
                      RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(50), // Rounded corners
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(
                      // Background color of the button
                      const Color(0xffc8d2d3),
                    ),
                  ),
                  child: Padding(
                    // Padding inside the button
                    padding: EdgeInsets.symmetric(
                        horizontal: 45, vertical: 10), // Padding values
                    child: Text(
                      "Login", // Text inside the button
                      style: TextStyle(
                        fontSize: 16, // Font size
                        fontWeight: FontWeight.bold, // Font weight
                        color: TrackerApp.primaryColor, // Text color
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ValidateData() {
    _email.text.isNotEmpty && _password.text.isNotEmpty
        ? CheckingData()
        : displayDialog();
  }

  displayDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) {
        return const ErrorAlertDialog(
          message: "Please Fill up the Information",
        );
      },
    );
  }

  CheckingData() async {
    showDialog(
      context: context,
      builder: (c) {
        return const LoadingAlertDialog(
          message: "Checking Data, Please Wait...",
        );
      },
    );
    _Login();
  }

  void _Login() async {
    await FirebaseAuth.instance
        .signInWithEmailAndPassword(
            email: _email.text.trim(), password: _password.text.trim())
        .then((auth) {
      callData(auth.user!.uid);
    }).catchError((error) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (c) => ErrorAlertDialog(
          message: error.toString(),
        ),
      );
    });
  }

  Future callData(String currentUser) async {
    await FirebaseFirestore.instance
        .collection("users")
        .doc(currentUser)
        .get()
        .then((results) async {
      TrackerApp.trmporallyData
          ?.setString("fullName", results.data()?['fullName']);
      String type = results.data()?['type'];
      switch (type) {
        case "parent":
          String status = results.data()?['status'];
          Navigator.pop(context);
          if (status == "Accepted") {
            Route route = MaterialPageRoute(
                builder: (_) => const CustomBottomNavigationParent());
            Navigator.pushAndRemoveUntil(context, route, (route) => false);
            TrackerApp.trmporallyData
                ?.setString("fullName", results['fullName']);
          } else {
            showDialog(
              context: context,
              builder: (c) => const ErrorAlertDialog(
                message:
                    "The Parent is not accepted yet or rejected. you can't login",
              ),
            );
          }
          break;
        case "seller":
          Route route =
              MaterialPageRoute(builder: (_) => const SellerbottomNavigation());
          Navigator.pushAndRemoveUntil(context, route, (route) => false);
          break;
        default:
          Route route =
              MaterialPageRoute(builder: (_) => const bottomNavigationAdmin());
          Navigator.pushAndRemoveUntil(context, route, (route) => false);
      }
      print("This is the type : ${type}");
    });
  }
}
