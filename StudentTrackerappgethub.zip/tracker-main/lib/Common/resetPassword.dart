import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';

class RestPassword extends StatefulWidget {
  const RestPassword({super.key});

  @override
  State<RestPassword> createState() => _RestPasswordState();
}

class _RestPasswordState extends State<RestPassword> {
  TextEditingController _email = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Image.asset("images/logo2.png"),
                  Text(
                    "Students Tracker",
                    style: TextStyle(
                      color: TrackerApp.primaryColor,
                      fontSize: 22,
                    ),
                  ),
                  Text(
                    "Rest Password",
                    style: TextStyle(
                      color: TrackerApp.secondTextColor,
                      fontSize: 22,
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 45,
                    margin: const EdgeInsets.all(5),
                    child: TextField(
                      obscureText: true,
                      controller: _email,
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        hintText: "Email",
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                        ),
                        isCollapsed: false,
                        isDense: true,
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1,
                            color: Color(0xffc8d2d3),
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        prefixIcon: Icon(
                          Icons.email, // Email icon
                          color: TrackerApp.primaryColor, // Icon color
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              ElevatedButton(
                // When it's clicked,
                onPressed: () {
                  // Defines the action to take when the button is pressed
                },
                style: ButtonStyle(
                  // Custom style for the button
                  shape: MaterialStateProperty.all(
                    // Shape of the button
                    RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(50), // Rounded corners
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(
                    // Background color of the button
                    const Color(0xffc8d2d3),
                  ),
                ),
                child: Padding(
                  // Padding inside the button
                  padding: EdgeInsets.symmetric(
                      horizontal: 45, vertical: 10), // Padding values
                  child: Text(
                    "Submit", // Text inside the button
                    style: TextStyle(
                      fontSize: 16, // Font size
                      fontWeight: FontWeight.bold, // Font weight
                      color: TrackerApp.primaryColor, // Text color
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
