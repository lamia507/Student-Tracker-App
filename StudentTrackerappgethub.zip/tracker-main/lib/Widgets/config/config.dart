import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TrackerApp {
  static Color primaryColor = const Color(0xffff6c38).withOpacity(0.9);
  static Color BackgroundColor = Color.fromRGBO(248, 210, 107, 11);
  static Color buttonColor = const Color(0xff6872ae);
  static Color textFiedlColor = const Color(0xffcdcdcc);
  static Color secondTextColor = const Color(0xffcd13c1);

  // Splash Screen Colors
  static Color circleColor1 = const Color(0xffba804e);
  static Color circleColor2 = const Color(0xff746096);
  static Color circleColor3 = const Color(0xff7fbedf);

  static SharedPreferences? trmporallyData;

  static MaterialColor createMaterialColor(Color color) {
    // Manually define the shades of the primary color
    Map<int, Color> colorShades = {
      50: const Color.fromRGBO(97, 108, 170, .1),
      100: const Color.fromRGBO(97, 108, 170, .2),
      200: const Color.fromRGBO(97, 108, 170, .3),
      300: const Color.fromRGBO(97, 108, 170, .4),
      400: const Color.fromRGBO(97, 108, 170, .5),
      500: const Color.fromRGBO(97, 108, 170, .6),
      600: const Color.fromRGBO(97, 108, 170, .7),
      700: const Color.fromRGBO(97, 108, 170, .8),
      800: const Color.fromRGBO(97, 108, 170, .9),
      900: const Color.fromRGBO(97, 108, 170, 1),
    };

    // Create a MaterialColor with the primary color value and its shades
    return MaterialColor(color.value, colorShades);
  }
}
