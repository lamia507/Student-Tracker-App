import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Common/resetPassword.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';
import 'package:tracker/Common/login.dart';
import 'package:tracker/Widgets/config/config.dart';

class ParentRegister extends StatefulWidget {
  const ParentRegister({super.key});

  @override
  State<ParentRegister> createState() => _ParentRegisterState();
}

class _ParentRegisterState extends State<ParentRegister> {
  TextEditingController _email = TextEditingController();
  TextEditingController _fullName = TextEditingController();
  TextEditingController _phneNumber = TextEditingController();
  TextEditingController _password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Image.asset("images/logo2.png"),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _email,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Email",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.email, // Email icon
                            color: TrackerApp.primaryColor, // Icon color
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: true,
                        controller: _password,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "********",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.lock, // Email icon
                            color: TrackerApp.primaryColor, //
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _fullName,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "Full Name",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.person,
                            color: TrackerApp.primaryColor, //
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 45,
                      margin: const EdgeInsets.all(5),
                      child: TextField(
                        obscureText: false,
                        controller: _phneNumber,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          hintText: "054343244",
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                          ),
                          isCollapsed: false,
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1,
                              color: Color(0xffc8d2d3),
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          prefixIcon: Icon(
                            Icons.phone,
                            color: TrackerApp.primaryColor,
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        TextButton(
                          onPressed: () {
                            Route route = MaterialPageRoute(
                                builder: (_) => RestPassword());
                            Navigator.push(context, route);
                          },
                          child: const Text("Forget Password?"),
                        ),
                      ],
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    ValidateData();
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(50), // Rounded corners
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(
                      const Color(0xffc8d2d3),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                    child: Text(
                      "Regsiter",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: TrackerApp.primaryColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ValidateData() {
    _email.text.isNotEmpty &&
            _fullName.text.isNotEmpty &&
            _password.text.isNotEmpty &&
            _phneNumber.text.isNotEmpty
        ? SavingData()
        : displayDialog();
  }

  displayDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) {
        return const ErrorAlertDialog(
          message: "Please Fill up the Information",
        );
      },
    );
  }

  SavingData() async {
    showDialog(
      context: context,
      builder: (c) {
        return const LoadingAlertDialog(
          message: "Saving Data, Please Wait...",
        );
      },
    );
    _ParentRegistering();
  }

  void _ParentRegistering() async {
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(
            email: _email.text.trim(), password: _password.text.trim())
        .then((auth) {
      saveUserInfo(auth.user!.uid);
    }).catchError((error) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (c) => ErrorAlertDialog(
          message: error.toString(),
        ),
      );
    });
  }

  Future saveUserInfo(String currentUser) async {
    await FirebaseFirestore.instance.collection("users").doc(currentUser).set({
      "uid": currentUser,
      "email": _email.text.trim(),
      "fullName": _fullName.text.trim(),
      "status": "Pending",
      "type": "parent",
      "phoneNumber": _phneNumber.text.trim(),
      "RegistredTime": DateTime.now(),
    }).then((value) {
      Route route = MaterialPageRoute(builder: (context) => Login());
      Navigator.pushReplacement(context, route);
    });
  }
}
