import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsPage extends StatelessWidget {
  final String email = 'admin@gmail.com';
  final String phoneNumber = '9200';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Us'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Get in touch with our team for assistance or inquiries about the Student Tracker Application.',
              style: TextStyle(fontSize: 18.0),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Email us at:'),
              subtitle: Text(email),
              onTap: () async {
                final Uri emailLaunchUri = Uri(
                  scheme: 'mailto',
                  path: email,
                );
                if (await canLaunch(emailLaunchUri.toString())) {
                  await launch(emailLaunchUri.toString());
                } else {
                  throw 'Could not launch $email';
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: const Text('For immediate support, call:'),
              subtitle: Text(phoneNumber),
              onTap: () async {
                final Uri phoneLaunchUri = Uri(
                  scheme: 'tel',
                  path: phoneNumber,
                );
                if (await canLaunch(phoneLaunchUri.toString())) {
                  await launch(phoneLaunchUri.toString());
                } else {
                  throw 'Could not launch $phoneNumber';
                }
              },
            ),
            // Additional information about the application could go here
          ],
        ),
      ),
    );
  }
}
