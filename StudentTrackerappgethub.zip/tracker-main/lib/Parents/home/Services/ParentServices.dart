import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:tracker/Parents/home/Services/Emergency/emergencyCall.dart';
import 'package:tracker/Parents/home/Services/Grades/AllStudentsToViewGrade.dart';
import 'package:tracker/Parents/home/Services/ManageStudents/AllStudents.dart';
import 'package:tracker/Parents/home/Services/Notifications/AllParentNotifications.dart';
import 'package:tracker/Parents/home/Services/wallet/studentWallet.dart';
import 'package:tracker/Widgets/config/config.dart';

class ParentServices extends StatefulWidget {
  const ParentServices({super.key});

  @override
  State<ParentServices> createState() => _ParentServicesState();
}

class _ParentServicesState extends State<ParentServices> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: GridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 5,
          children: [
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (context) => const AllStudents());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: const Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text("Students",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      Icon(Icons.school, color: Colors.blue, size: 40),
                    ],
                  ),
                ),
              ),
            ),

            // Wallet Card
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const studentWallet());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: const Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text("Wallet",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      Icon(Icons.account_balance_wallet,
                          color: Colors.green, size: 40),
                    ],
                  ),
                ),
              ),
            ),

            // Grade Card
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (_) => const AllStudentsToViewGrade());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: const Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text("Grade",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      Icon(Icons.grade, color: Colors.amber, size: 40),
                    ],
                  ),
                ),
              ),
            ),

            // Emergency Call Card
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => const EmergencyCall());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: const Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text("Emergency Call",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      Icon(Icons.call, color: Colors.pink, size: 40),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Route route = MaterialPageRoute(
                    builder: (_) => const AllParentNotifications());
                Navigator.push(context, route);
              },
              child: Card(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white, // Background color for the container
                    borderRadius: BorderRadius.circular(
                      5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                            0.15), // Shadow color with some transparency
                        spreadRadius:
                            0, // Extend the shadow to all sides by 1 unit
                        blurRadius:
                            5, // The higher the blur radius, the more spread out the shadow
                        offset:
                            const Offset(0, 3), // Position of the shadow (x, y)
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        "Notifications",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(Icons.notifications,
                          color: TrackerApp.primaryColor, size: 50),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
