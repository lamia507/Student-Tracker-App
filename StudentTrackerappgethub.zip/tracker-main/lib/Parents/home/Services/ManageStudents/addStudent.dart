import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'dart:ui' as ui;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Widgets/loadingDialog/errorDialog.dart';
import 'package:tracker/Widgets/loadingDialog/loadingDialog.dart';

class AddStudent extends StatefulWidget {
  const AddStudent({Key? key}) : super(key: key);

  @override
  State<AddStudent> createState() => _AddStudentState();
}

class _AddStudentState extends State<AddStudent> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _ageController = TextEditingController();
  TextEditingController _addressController = TextEditingController();
  TextEditingController _emergencyNumber1Controller = TextEditingController();
  TextEditingController _emergencyNumber2Controller = TextEditingController();
  TextEditingController _emergencyNumber3Controller = TextEditingController();
  TextEditingController _healthConditionController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _qrData = ''; // Variable to store QR data
  late var ImageFIle;
  String? imageURL;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text("Add Student", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildTextField(_emailController, "Email", Icons.email),
                  _buildTextField(_nameController, "Name", Icons.person),
                  _buildTextField(_ageController, "Age", Icons.calendar_today),
                  _buildTextField(_addressController, "Address", Icons.home),
                  _buildTextField(_emergencyNumber1Controller,
                      "Emergency Number 1", Icons.phone),
                  _buildTextField(_emergencyNumber2Controller,
                      "Emergency Number 2", Icons.phone),
                  _buildTextField(_emergencyNumber3Controller,
                      "Emergency Number 3", Icons.phone),
                  _buildTextField(_healthConditionController,
                      "Health Condition", Icons.local_hospital),
                  const SizedBox(height: 20),
                  _qrData.isNotEmpty
                      ? QrImageView(
                          data: _qrData,
                          version: QrVersions.auto,
                          size: 200.0,
                        )
                      : Container(), // Conditionally display QR code
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        ValidaitingDate();
                      }
                    },
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(TrackerApp.primaryColor),
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30))),
                    ),
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 45, vertical: 10),
                      child: Text(
                        "Add Student",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return Container(
      margin: const EdgeInsets.all(5),
      child: TextFormField(
        controller: controller,
        cursorColor: Colors.black,
        decoration: InputDecoration(
          hintText: label,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: TrackerApp.primaryColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: TrackerApp.primaryColor),
            borderRadius: BorderRadius.circular(30),
          ),
          prefixIcon: Icon(icon, color: TrackerApp.primaryColor),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
      ),
    );
  }

  // هذه الدالة تُستخدم لإنشاء صورة لرمز QR بناءً على بيانات مُدخلة وحفظها كملف
  Future<File> generateQrCodeImage(String data) async {
    // التحقق من صحة بيانات رمز QR
    final qrValidationResult = QrValidator.validate(
      data: data, // البيانات المراد تحويلها إلى رمز QR
      version: QrVersions.auto, // النسخة التلقائية لتحديد حجم رمز QR
      errorCorrectionLevel:
          QrErrorCorrectLevel.L, // مستوى تصحيح الأخطاء لرمز QR
    );

    if (!qrValidationResult.isValid) {
      // إذا كانت البيانات غير صالحة، يتم إلقاء استثناء
      throw Exception('Invalid QR data');
    }

    // إنشاء رمز QR بناءً على البيانات المُدخلة
    final qrCode = qrValidationResult.qrCode!; // الحصول على كائن رمز QR
    final painter = QrPainter.withQr(
      qr: qrCode, // تعيين رمز QR للرسام
      gapless: false, // إذا كان true، يزيل الفجوات الصغيرة بين البكسلات
    );

    // تحويل رمز QR إلى صورة
    final pictureRecorder =
        ui.PictureRecorder(); // يُستخدم لتسجيل العمليات الرسومية
    final canvas = Canvas(pictureRecorder); // إنشاء قماش للرسم
    const size = Size.square(200); // تحديد حجم الصورة المُراد إنشاؤها
    painter.paint(canvas, size); // رسم رمز QR على القماش
    final picture =
        pictureRecorder.endRecording(); // إنهاء التسجيل والحصول على الصورة
    final image = await picture.toImage(
        200, 200); // تحويل الصورة إلى شكل نهائي بالحجم المُحدد
    final byteData = await image.toByteData(
        format: ui.ImageByteFormat.png); // تحويل الصورة إلى بيانات بتنسيق PNG
    final pngBytes =
        byteData!.buffer.asUint8List(); // الحصول على بيانات الصورة كمصفوفة بت

    // حفظ الصورة كملف
    final tempDir =
        await getTemporaryDirectory(); // الحصول على مسار المجلد المؤقت
    final file = File('${tempDir.path}/qr.png'); // إنشاء ملف جديد للصورة
    await file.writeAsBytes(pngBytes); // كتابة بيانات الصورة إلى الملف

    return file; // إرجاع الملف الذي يحتوي على الصورة
  }

  ValidaitingDate() async {
    showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return const LoadingAlertDialog(
          message: "Adding student, please wait...",
        );
      },
    );
    String documentId =
        FirebaseFirestore.instance.collection('students').doc().id;

    String currentUser = FirebaseAuth.instance.currentUser?.uid ?? "";
    // Gettign QR Code
    await gettingImageURL(documentId);

    print("Data data ${imageURL}");

    await FirebaseFirestore.instance
        .collection('students')
        .doc(documentId)
        .set({
      'email': _emailController.text.trim(),
      'name': _nameController.text.trim(),
      'age': _ageController.text.trim(),
      'Money': "",
      'address': _addressController.text.trim(),
      'emergencyNumber1': _emergencyNumber1Controller.text.trim(),
      'emergencyNumber2': _emergencyNumber2Controller.text.trim(),
      'emergencyNumber3': _emergencyNumber3Controller.text.trim(),
      'healthCondition': _healthConditionController.text.trim(),
      'parentID': currentUser,
      'qrData': imageURL, // This will be generated later
      'createdOn': FieldValue.serverTimestamp(),
    }).then((_) {
      setState(() {
        _qrData =
            'ID: $documentId, Name: ${_nameController.text}'; // Generate QR data
      });
      Navigator.pop(context); // Close the loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Student added successfully')));
      _emailController.clear();
      _nameController.clear();
      _ageController.clear();
      _addressController.clear();
      _emergencyNumber1Controller.clear();
      _emergencyNumber2Controller.clear();
      _emergencyNumber3Controller.clear();
      _healthConditionController.clear();
    }).catchError((error) {
      Navigator.pop(context); // Close the loading dialog
      showDialog(
        context: context,
        builder: (BuildContext context) =>
            ErrorAlertDialog(message: "Failed to add student: $error"),
      );
    });
  }

  Future<String> gettingImageURL(String documentId) async {
    final File qrImageFile = await generateQrCodeImage(documentId);

    if (qrImageFile.path.isNotEmpty) {
      String imageName =
          "QRS/${DateTime.now().microsecondsSinceEpoch.toString()}.png";
      FirebaseStorage storage = FirebaseStorage.instance;
      TaskSnapshot snapshot = await storage.ref(imageName).putFile(qrImageFile);
      final String downloadUrl = await snapshot.ref.getDownloadURL();
      imageURL = downloadUrl;
      return downloadUrl;
    } else {
      throw Exception('QR Image file not found');
    }
  }
}
