import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Parents/home/Services/ManageStudents/EditStudents.dart';
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/Parents/home/Services/ManageStudents/addStudent.dart';

class AllStudents extends StatefulWidget {
  const AllStudents({Key? key}) : super(key: key);

  @override
  State<AllStudents> createState() => _AllStudentsState();
}

class _AllStudentsState extends State<AllStudents> {
  String? currentUser = FirebaseAuth.instance.currentUser?.uid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TrackerApp.primaryColor,
        title: const Text(
          "View Students",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Route route = MaterialPageRoute(builder: (_) => const AddStudent());
          Navigator.push(context, route);
        },
        backgroundColor: TrackerApp.primaryColor,
        child: const Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('students')
            .where("parentID", isEqualTo: currentUser)
            .snapshots(), // Removed where("parentID") to fix the query
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final students = snapshot.data!.docs;

          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              var student = students[index].data() as Map<String,
                  dynamic>; // Cast each document to Map<String, dynamic>
              return Card(
                // Using Card for better UI presentation
                margin: const EdgeInsets.all(10),

                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Name: ${student['name']}",
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text("Email: ${student['email']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text("Age: ${student['age']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text("Address: ${student['address']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 1: ${student['emergencyNumber1']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 2: ${student['emergencyNumber2']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text(
                          "Emergency Contact 3: ${student['emergencyNumber3']}",
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 5),
                      Text("Health Condition: ${student['healthCondition']}",
                          style: const TextStyle(fontSize: 16)),
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Image.network(student['qrData']),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) =>
                                    EditStudent(studentId: students[index].id),
                              ));
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteStudent(students[index].id),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _deleteStudent(String studentId) async {
    await FirebaseFirestore.instance
        .collection('students')
        .doc(studentId)
        .delete()
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Student deleted successfully'),
        ),
      );
    });
  }
}
