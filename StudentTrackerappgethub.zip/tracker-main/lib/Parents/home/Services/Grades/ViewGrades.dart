import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';

class ViewGrades extends StatefulWidget {
  final String studentId;

  const ViewGrades({Key? key, required this.studentId}) : super(key: key);

  @override
  State<ViewGrades> createState() => _ViewGradesState();
}

class _ViewGradesState extends State<ViewGrades> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Student's Grades",
            style: TextStyle(color: Colors.white)),
        backgroundColor: TrackerApp.primaryColor,
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('students')
            .doc(widget.studentId)
            .collection('grades')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final grades = snapshot.data!.docs;
          if (grades.isEmpty) {
            return const Center(child: Text("No grades found."));
          }

          return ListView.builder(
            itemCount: grades.length,
            itemBuilder: (context, index) {
              var grade = grades[index].data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  leading: Icon(Icons.score, color: TrackerApp.primaryColor),
                  title: Text("${grade['semester']}: ${grade['averageGrade']}%",
                      style: TextStyle(fontSize: 18)),
                  subtitle: Text(
                      "Added on: ${grade['timestamp'].toDate().toString()}"),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
