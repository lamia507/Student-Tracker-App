import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/Parents/home/chat/chatPage.dart';
import 'package:tracker/Widgets/config/config.dart';

class AllAdminChat extends StatefulWidget {
  const AllAdminChat({super.key});

  @override
  State<AllAdminChat> createState() => _AllAdminChat();
}

class _AllAdminChat extends State<AllAdminChat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where("type", isEqualTo: "admin")
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final parents = snapshot.data!.docs;

          return ListView.builder(
            itemCount: parents.length,
            itemBuilder: (context, index) {
              var parent = parents[index];
              return Container(
                margin: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: TrackerApp.textFiedlColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        child: Text(parent['fullName']
                            [0]), // Display first letter of the name
                      ),
                      title: Text(parent['fullName']),
                      subtitle: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Email: ${parent['email']}'),
                          Text('Phone Number: ${parent['phoneNumber']}'),
                        ],
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.chat, color: TrackerApp.primaryColor),
                        onPressed: () {
                          addingChatCollections(parent.id, parent['fullName']);
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  addingChatCollections(String adminID, adminName) async {
    String parentID = FirebaseAuth.instance.currentUser?.uid ?? "";
    String fullName =
        TrackerApp.trmporallyData?.getString("fullName").toString().trim() ??
            "";
    // check if it exisit
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("chats")
        .where("adminID", isEqualTo: adminID)
        .where("parentID", isEqualTo: parentID)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatPage(
            adminID: querySnapshot.docs[0]['adminID'],
            adminName: querySnapshot.docs[0]['parentID'],
            chatID: querySnapshot.docs[0].id,
          ),
        ),
      );
    } else {
      await FirebaseFirestore.instance.collection("chats").add(
        {
          "adminID": adminID,
          "parentID": parentID,
          'parentName': fullName,
          "date": DateTime.now(),
          "adminName": adminName,
        },
      ).then((results) {
        var asdf = results.get();
        asdf.then((response) {
          response.data()?['parentID'];
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatPage(
                adminID: response.data()?['adminID'],
                adminName: response.data()?['adminName'],
                chatID: response.id,
              ),
            ),
          );
        });
      });
    }
  }
}
