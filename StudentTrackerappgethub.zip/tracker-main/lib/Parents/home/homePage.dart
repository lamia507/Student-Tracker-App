import 'package:flutter/material.dart';
import 'package:tracker/Widgets/config/config.dart';

class ParentHomePage extends StatefulWidget {
  const ParentHomePage({super.key});

  @override
  State<ParentHomePage> createState() => _ParentHomePageState();
}

class _ParentHomePageState extends State<ParentHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Welcome",
              style: TextStyle(
                  color: TrackerApp.primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 40),
            ),
            const Text("To Our Application")
          ],
        ),
      ),
    );
  }
}
