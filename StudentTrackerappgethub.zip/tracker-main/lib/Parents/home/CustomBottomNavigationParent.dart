import 'package:flutter/material.dart';
import 'package:tracker/Parents/Profile/ParentProfilePage.dart';
import 'package:tracker/Parents/home/Services/ParentServices.dart';
import 'package:tracker/Parents/home/chat/allChats.dart';
import 'package:tracker/Parents/home/homePage.dart';
import 'package:tracker/Widgets/config/config.dart';

class CustomBottomNavigationParent extends StatefulWidget {
  const CustomBottomNavigationParent({super.key});

  @override
  State<CustomBottomNavigationParent> createState() =>
      _CustomBottomNavigationParent();
}

class _CustomBottomNavigationParent
    extends State<CustomBottomNavigationParent> {
  int currentIndex = 0;
  final List<Widget> pages = [
    ParentHomePage(),
    ParentServices(),
    AllAdminChat(),
    ParentProfilePage(),
  ];

  final List<String> titles = [
    "Home",
    "Service",
    "Chat",
    "Profile Information",
  ];

  void _updatingIndex(int newSelectedIndex) {
    setState(() {
      currentIndex = newSelectedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          titles[currentIndex],
          style: const TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: TrackerApp.primaryColor,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home), // Valid icon
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.build), // Valid icon
            label: "Service",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat), // Valid icon
            label: "Chat",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle), // Valid icon
            label: "Profile",
          ),
        ],
        onTap: _updatingIndex,
        currentIndex: currentIndex,
        showUnselectedLabels: true,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black54,
        backgroundColor: TrackerApp.primaryColor,
        type: BottomNavigationBarType.fixed,
      ),
      body: pages.elementAt(currentIndex),
    );
  }
}
