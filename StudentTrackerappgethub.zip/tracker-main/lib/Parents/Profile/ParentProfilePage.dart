import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:tracker/Common/ChoicePage.dart';
import 'package:tracker/Parents/Profile/ParentEditProiflePage.dart';
import 'package:tracker/Parents/contactUS/contact.dart';
import 'package:tracker/Seller/Profile/EditProfile.dart';
import 'package:tracker/Widgets/config/config.dart';

class ParentProfilePage extends StatefulWidget {
  const ParentProfilePage({super.key});

  @override
  State<ParentProfilePage> createState() => _ParentProfilePageState();
}

class _ParentProfilePageState extends State<ParentProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.person,
              size: 100,
            ),
            Text(
              "Parent",
              style: TextStyle(
                color: TrackerApp.primaryColor,
                fontSize: 25,
              ),
            ),
            const Divider(),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => ContactUsPage());
                Navigator.push(context, route);
              },
              child: const ListTile(
                title: Text("Contact Us"),
                leading: Icon(
                  Icons.contact_page,
                ),
                trailing: Icon(Icons.arrow_forward),
              ),
            ),
            const Divider(),
            GestureDetector(
              onTap: () {
                Route route =
                    MaterialPageRoute(builder: (_) => ParentEditProiflePage());
                Navigator.push(context, route);
              },
              child: const ListTile(
                title: Text("Edit Profile"),
                leading: Icon(
                  Icons.edit,
                ),
                trailing: Icon(Icons.arrow_forward),
              ),
            ),
            const Divider(),
            GestureDetector(
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Route route = MaterialPageRoute(
                    builder: (_) => const ChoicePage(),
                  );
                  Navigator.push(context, route);
                });
              },
              child: const ListTile(
                title: Text("Log out"),
                leading: Icon(
                  Icons.logout,
                ),
                trailing: Icon(Icons.arrow_forward),
              ),
            ),
            const Divider(),
          ],
        ),
      ),
    );
  }
}
