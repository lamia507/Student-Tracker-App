// استيراد حزمة مواد الواجهة من فلاتر، والتي تحتوي على العديد من الويدجتس والأدوات المساعدة لبناء التطبيقات.
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tracker/Common/SplashScreen.dart';
// استيراد ملف التكوين من مشروعك، والذي يمكن أن يحتوي على ثوابت وإعدادات عامة للتطبيق.
import 'package:tracker/Widgets/config/config.dart';
import 'package:tracker/firebase_options.dart';
// استيراد صفحة تسجيل الدخول من مشروعك، والتي تتيح للمستخدمين الوصول إلى التطبيق بعد التحقق من هويتهم.
// استيراد ويدجت التنقل السفلي من مشروعك، والذي يمكن استخدامه للتنقل بين صفحات مختلفة داخل التطبيق.

// الدالة الرئيسية للبرنامج، وهي نقطة البداية لتشغيل التطبيق.
Future<void> main() async {
  // التأكد من أن واجهات فلاتر جاهزة للاستخدام قبل تشغيل التطبيق.
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    // Initializing Firebase
    options: DefaultFirebaseOptions
        .currentPlatform, // Using default Firebase options for the current platform
  );
  TrackerApp.trmporallyData = await SharedPreferences.getInstance();

  // تشغيل التطبيق باستخدام ويدجت MyApp كنقطة انطلاق.
  runApp(MyApp());
}

// تعريف كلاس MyApp، والذي يمثل الواجهة الرئيسية للتطبيق.
class MyApp extends StatelessWidget {
  // تعريف الدالة build التي تبني واجهة المستخدم للتطبيق.
  @override
  Widget build(BuildContext context) {
    // إرجاع ويدجت MaterialApp، والذي يوفر إطار عمل لبناء التطبيقات التي تتبع تصميم مواد جوجل.
    return const MaterialApp(
      // إخفاء الشريط العلوي الذي يظهر في وضع الديباج لجعل التطبيق يبدو أكثر احترافية عند النشر.
      debugShowCheckedModeBanner: false,
      // تعيين السمة الأساسية للتطبيق باستخدام ThemeData.
      // تحديد الصفحة الرئيسية للتطبيق باستخدام ويدجت CustomeBottomNavigation للتنقل السفلي.
      home: SplashScreen(),
    );
  }
}
